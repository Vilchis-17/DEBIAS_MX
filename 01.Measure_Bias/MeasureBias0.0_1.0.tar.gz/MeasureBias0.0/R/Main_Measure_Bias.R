# ==============================================================================
# ================================= exe() ======================================
# ==============================================================================
#' exe()
#'
#' This function performs complete data analysis. This function coordinates
#' the loading, cleaning, analysis and visualization of the data.
#'
#' @param
#'        none
#' @return
#'        A folder with analysis results
#' @examples
#'        exe()
#' @export
exe <- function()
{
  # E X P L A I N      B I A S
  # Clear workspace
  rm(list=ls())
  F_Load_dependences()
  # load font
  font_add_google("Roboto Condensed", "robotocondensed")
  # automatically use showtext to render text
  showtext_auto()
while (TRUE)
{
  # ============================================================================== 0.MENU
  print("=========================================================================")
  print("================ M A I N    M E A S U R E   B I A S =====================")
  print("=========================================================================")
  print("0.Exit")
  print("1.Get all the bias files:")
  print("   -Nonspatial")
  print("   -Queen")
  print("   -Fbw")
  print("   -Knn")
  print("   -Db")
  print("=========================================================================")
  while (TRUE){
    entry <- readline(prompt = "Enter the option: ")
    if (grepl("^[0-1]+$", entry)) {
      entry <- as.integer(entry)
      break
    } else {
      cat("Invalid option. Please enter an option[0 - 1]..\n")
    }
  }
  if(entry == 0)
  {
    break
  }
  print("================================================================ 1.PARAMETERS")
  if(entry == 1)
  {
    print("=========================================================================")
    print("======================= 1.Get all the bias files ========================")
    print("=========================================================================")
    ####Outputs <- "TEST_PAquete"
    Outputs <- readline(prompt = "Enter a name for the results folder:")

    #### num_classes <- 8
    num_classes <- NULL
    while (TRUE) {
      num_classes_input <- readline(prompt = "Enter the number of classes for plots [2 - 10] Example: 8: ")
      if (grepl("^(?:[2-9]|10)$", num_classes_input)){
        num_classes <- as.integer(num_classes_input)
        break
      } else {
        cat("Invalid input. Please enter a number between 2 and 10 (e.g., 2, 5, 10). Letters are not allowed.\n")
      }
    }
    w_schemes <- c("queen", "fbw", "knn", "db")
    print("=========================================================================")
    print("*** Please verify parameters ***")
    print("=========================================================================")
    print(paste("Outputs:",Outputs))
    print(paste("Number of classes for plots:",num_classes))
    print("=========================================================================")
    continue <- readline(prompt = "Press ENTER to continue or 0 to return to the main menu: ")
    if (continue == "0")
      next
  }
  print("======================================================================= 2.DATA")
  print("***The following data are required: ***")
  print("==============================================================================")
  print("1.Population data    (CSV)")
  print("2.Geographical areas (SHP)")
  print("3.Active population  (CSV)")
  print("==============================================================================")
  print("================================================================================= Population data")
  continue <- readline(prompt = "Press ENTER to load POPULATION DATA or 0 to return to the main menu: ")
  if (continue == "0")
    next
  #### Population_data <- read.csv("Inputs/01.Census2020_Mun_Población.csv", fileEncoding = "latin1")
  Population_data <- read.csv(file.choose(), fileEncoding = "latin1")
  colnames(Population_data)[1] <- "Area_code"
  colnames(Population_data)[2] <- "Area_name"
  colnames(Population_data)[3] <- "Total_Population"
  Population_data <- Population_data %>% select(Area_code, Area_name, Total_Population)
  # Verify data
  print(head(Population_data,n=5))
  # Verify dimensions
  print("Dimensions:")
  print(dim(Population_data))
  # Verify missing values
  print("Missing values:")
  print(t(t(colSums(is.na(Population_data)))))

  print("================================================================================= Geographical areas")
  continue <- readline(prompt = "Press ENTER to load GEOGRAPHICAL AREAS DATA (.shp) or 0 to return to the main menu: ")
  if (continue == "0")
    next
  #### Geographical_areas <- st_read("Inputs/SHP/MunicipiosMX.shp")
  Geographical_areas <- st_read(file.choose())
  colnames(Geographical_areas)[1] <- "Area_code"
  Boundaries <- Geographical_areas

  Geographical_areas <-  Geographical_areas %>%
    select(Area_code, geometry)

  # Verify data
  print(head(Geographical_areas,n=5))
  # Verify dimensions
  print("Dimensions:")
  print(dim(Geographical_areas))
  # Verify missing values
  print("Missing values:")
  print(t(t(colSums(is.na(Geographical_areas)))))
  # =================================================================================
  # Simplifies the complexity of spatial geometries
  Boundaries <- Boundaries %>%st_simplify(preserveTopology = TRUE, dTolerance = 1000)
  # Transforms the coordinate system of spatial geometries
  Boundaries <- st_transform(Boundaries,  crs = 4326)

  # Verify data
  print(head(Boundaries,n=5))
  # Verify dimensions
  print("Dimensions:")
  print(dim(Boundaries))
  # Verify missing values
  print("Missing values:")
  print(t(t(colSums(is.na(Boundaries)))))

  print("================================================================================= Active population")
  continue <- readline(prompt = "Press ENTER to load ACTIVE POPULATION or 0 to return to the main menu: ")
  if (continue == "0")
    next

  #### Active_population <- read.csv("Inputs/Active_population_fb_tts.csv", fileEncoding = "latin1")
  Active_population <- read.csv(file.choose(), fileEncoding = "latin1")
  colnames(Active_population)[1] <- "Area_code"
  colnames(Active_population)[2] <- "Area_name"
  colnames(Active_population)[3] <- "Total_active_population"

  Active_population <- Active_population %>% select(Area_code, Area_name, Total_active_population) %>%
    mutate(Area_code = as.integer(Area_code))

  # Verify data
  print(head(Active_population,n=5))
  # Verify dimensions
  print("Dimensions:")
  print(dim(Active_population))
  # Verify missing values
  print("Missing values:")
  print(t(t(colSums(is.na(Active_population)))))
  print("=========================================================================")
  continue <- readline(prompt = "Press ENTER to continue or 0 to return to the main menu: ")
  if (continue == "0")
    next

  print("================================================================ 3.MEASURE BIAS")
  Bias_measurement <- F_Measure_bias(Population_data,Active_population)
  print("Dimensions:")
  print(dim(Bias_measurement))
  print(head(Bias_measurement,n=5))
  # Copy dataframe
  Bias_measurement_ORI <- Bias_measurement
  print("================================================================ 3.1.Missing Values - Listwise deletion")
  # Check for missing values
  Missing_values <- sum(is.na(Bias_measurement))
  print(paste0("   Missing values: ",Missing_values))
  print("========================")

  if(Missing_values > 0)
  {
    print("Before listwise deletion")
    print("========================")
    print(t(t(colSums(is.na(Bias_measurement)))))
    print("========================")
    print("Dimension")
    print(dim(Bias_measurement))
    print("========================")

    # 1.Identify the rows with NA
    rows_na <- which(rowSums(is.na(Bias_measurement)) > 0)

    # 2.Create a new dataframe with the rows with NA named Bias_measurement_NA
    Bias_measurement_NA <- Bias_measurement[rows_na, ]

    # 3.Dropping missing values from Bias_measurement
    Bias_measurement <- na.omit(Bias_measurement)

    # Check for missing values
    print("========================")
    print("After listwise deletion")
    print("========================")
    print(t(t(colSums(is.na(Bias_measurement)))))
    print("========================")
    print("Dimension")
    print(dim(Bias_measurement))
    print("========================")
    print("Dimension missing values")
    print(dim(Bias_measurement_NA))
    print("========================")
  }
  print("================================================================ 3.2.Dropping Negative Bias")
  # Check for negative bias
  Negative_bias <- sum(Bias_measurement$bias < 0)
  print(paste0("   Negative values: ",Negative_bias))
  print("========================")

  if(Negative_bias > 0)
  {
    # 1.Create a new dataframe with the rows with negative bias named Bias_measurement_NEG
    Bias_measurement_NEG <- Bias_measurement %>% filter(bias < 0)
    print("Dimension negative values")
    print(dim(Bias_measurement_NEG))
    print("========================")

    # 2.Dropping negative values from Bias_measurement
    Bias_measurement <- Bias_measurement %>% filter(bias > 0)
    print("Dimension positive values")
    print(dim(Bias_measurement))
    print("========================")

    # Check for negative bias
    Negative_bias_ <- sum(Bias_measurement$Bias < 0)
    print(paste0("   Negative values: ",Negative_bias_))
    print("========================")
  }
  print("================================================================ 3.3.Data information")
  # Total Population
  di_total_population  <- sum(Population_data$Total_Population)

  # Active Population
  di_active_population <- sum(Active_population$Total_active_population)

  # Coverage
  di_coverage          <- (di_active_population/di_total_population)*100

  # Total areas from SHP file
  di_total_areas       <- dim(Boundaries)[1]

  # Areas from total population
  di_areas_from_total_population <- dim(Population_data)[1]

  # Areas from active population
  di_areas_from_active_population <- dim(Active_population)[1]

  # Missing values areas
  if(Missing_values > 0){
    di_missing_values_areas <- dim(Bias_measurement_NA)[1]
  }else{
    di_missing_values_areas <- 0
  }

  # Areas after missing values treatment
  di_areas_after_missing <- (di_areas_from_total_population - di_missing_values_areas)

  # Negative bias areas
  if(Negative_bias > 0){
    di_negative_bias_areas <- dim(Bias_measurement_NEG)[1]
  }else{
    di_negative_bias_areas <- 0
  }

  # Areas after negative bias treatment
  di_areas_after_negative <- dim(Bias_measurement)[1]

  # Pearson correlation
  di_pearson_correlation <- cor(Bias_measurement$Total_Population, Bias_measurement$Total_active_population)

  # Create dataframe
  data_information <- data.frame(
    Metric = c("Total population",
               "Active population",
               "Coverage",
               "Total areas from SHP file",
               "Areas from total population",
               "Areas from active population",
               "Missing values areas",
               "Areas after missing values treatment",
               "Negative bias areas",
               "Areas after negative bias treatment",
               "Pearson correlation"),
    Value = c(di_total_population,
              di_active_population,
              di_coverage,
              di_total_areas,
              di_areas_from_total_population,
              di_areas_from_active_population,
              di_missing_values_areas,
              di_areas_after_missing,
              di_negative_bias_areas,
              di_areas_after_negative,
              di_pearson_correlation)
  )

  # Format columns
  data_information$Value <- ifelse(data_information$Metric == "Coverage",
                                   sprintf("%.2f", data_information$Value),
                                   ifelse(data_information$Metric == "Pearson correlation",
                                          sprintf("%.2f", data_information$Value),
                                          sprintf("%.0f", data_information$Value)))

  # Print dataframe
  print(data_information)
  print("================================================================ 3.4. Correlation graph")
  correlation_graph <- F_Correlation_graph(Bias_measurement)
  print("================================================================ 3.5.Create folders for outputs and saving")
  F_Create_outputs_folder(Outputs)
  print("================================================================ 3.5.1.Saving data information")
  F_Saving_data_information(Outputs,data_information)
  print("================================================================ 3.5.2.Saving correlation graph")
  F_Saving_correlation_graph(Outputs,correlation_graph)
  print("================================================================ 3.5.3.Saving Measure bias")
  F_Saving_measure_bias(Outputs,Bias_measurement)
  # MISSING VALUES
  if(Missing_values > 0)
  {
    print("================================================================ 3.5.4.Saving Missing values")
    F_Saving_missing_values(Outputs,Bias_measurement_NA)
    #rm(Bias_measurement_NA)
  }
  # NEGATIVE BIAS
  if(Negative_bias > 0)
  {
    print("================================================================ 3.5.5.Saving Negative bias")
    F_Saving_negative_bias(Outputs,Bias_measurement_NEG)
    #rm(Bias_measurement_NEG)
  }
  # ORIGINAL DATA WITH MISSING VALUES AND/OR NEGATIVE BIAS
  if(Missing_values > 0 || Negative_bias > 0)
  {
    print("================================================================ 3.5.6.Saving original data")
    F_Saving_original_data(Outputs,Bias_measurement_ORI)
    #rm(Bias_measurement_ORI)
  }
  print("================================================================ 4.SCATTER PLOT")
  Scatter_plot <- F_Scatter_plot(Bias_measurement,num_classes)
  print("================================================================ 4.1.Saving scatter plot")
  F_Saving_scatter_plot(Outputs,Scatter_plot)
  print("================================================================ 5.HISTOGRAM BIAS")
  print("================================================================ 5.1.Labelled histogram")
  Labelled_histogram   <- F_Labelled_Unlabelled_Histograms(Bias_measurement,num_classes,1)
  print("================================================================ 5.1.1Saving labelled histogram")
  F_Saving_labelled_histogram(Outputs,Labelled_histogram)
  print("================================================================ 5.2.Unlabelled histogram")
  Unlabelled_histogram <- F_Labelled_Unlabelled_Histograms(Bias_measurement,num_classes,0)
  print("================================================================ 5.2.1.Saving unlabelled histogram")
  F_Saving_unlabelled_histogram(Outputs,Unlabelled_histogram)
  print("================================================================ 5.3.Adjusted unlabelled histogram")
  hist_data <- data.frame(value = Bias_measurement$bias*100)
  minimum_x <- sort(hist_data$value)[1]
  print(paste0("Minimum x:",minimum_x))
  # Adjusted plot only if the minimum value is < 50
  if (minimum_x < 50)
  {
    Adjusted_unlabelled_histogram <- F_Adjusted_unlabelled_histogram(Bias_measurement,num_classes)
    print("================================================================ 5.3.1.Saving adjusted unlabelled histogram")
    F_Saving_adjusted_unlabelled_histogram(Outputs,Adjusted_unlabelled_histogram)
  }
  print("================================================================ 6.SPATIAL AUTOCORRELATION")
  # Casting "Area_code" as integer in order to use left_join
  Boundaries <- Boundaries %>%
    mutate(Area_code = as.integer(Area_code))
  Bias_map <- Boundaries %>% left_join(Bias_measurement, by = "Area_code") %>% st_as_sf()
  # Verify data
  print(head(Bias_map,n=5))
  print("================================================================ Data missing treatment")
  # Check for missing values
  print(t(t(colSums(is.na(Bias_map)))))
  print(dim(Bias_map))
  Bias_map <- na.omit(Bias_map)
  print(t(t(colSums(is.na(Bias_map)))))
  print(dim(Bias_map))
  print("================================================================ 6.1.Option 1: Queen")
  {
    if ("bias_w" %in% colnames(Bias_map)) {
      Bias_map <- Bias_map[, !names(Bias_map) %in% "bias_w"]
    }
    suffix <- '_w_queen'

    # Extract the coordinates of the centroids (or your points)
    coords <- st_coordinates(st_centroid(Bias_map))

    # Create queen neighbours list
    nb_q <- poly2nb(Bias_map, queen = TRUE)
    subgraphs <- n.comp.nb(nb_q)$nc

    # Create a row-standardised spatial weights matrix
    w_matrix <- nb2listw(nb_q, style = "W", zero.policy = TRUE)

    # Compute spatial lag
    bias_w <- lag.listw(w_matrix, Bias_map$bias, NAOK = TRUE)

    # Save spatial lag in additional column
    Bias_map$bias_w <- bias_w

    cat("The number of disconnected subgraphs for queen is: ", subgraphs, "\n")

    Bias_map_queen  <- Bias_map
    subgraphs_queen <- subgraphs
    w_matrix_queen  <- w_matrix
  }
  print("================================================================ 6.2.Option 2: Finding optimal fixed band width")
  {
    if ("bias_w" %in% colnames(Bias_map)) {
      Bias_map <- Bias_map[, !names(Bias_map) %in% "bias_w"]
    }
    suffix <- '_w_fbw'
    coords <- st_coordinates(st_centroid(Bias_map))
    # find optimal kernel bandwidth using cross validation
    fbw <- gwr.sel(Map_bias ~ 1,
                   data = Bias_map,
                   coords=cbind( coords[, "X"], coords[, "Y"]),
                   longlat = TRUE,
                   adapt = FALSE,
                   gweight = gwr.Gauss,
                   verbose = FALSE)
    # Create a distance-based neighbors list with a minimum distance of 0 and maximum   distance given by fbw
    nb_d <- dnearneigh(st_coordinates(st_centroid(Bias_map)), d1=0, d2=fbw)
    # Subgraphs
    subgraphs <- n.comp.nb(nb_d)$nc
    # Create a row-standardised spatial weights matrix using distance-based neighbors
    w_matrix <- nb2listw(nb_d, style = "W", zero.policy=TRUE)
    # WARNING!!!!! This weights matrix leaves too many observations disconnected. Below we print the percentage of observations with no neighbors:
    # Find the number of observations with zero neighbors
    zero_neighbors_count <- sum(unlist(lapply(w_matrix$weights, length)) == 0)
    zero_neighbors_count <- (zero_neighbors_count/nrow(Bias_map)*100)
    zero_neighbors_count
    # Compute spatial lag
    bias_w <- lag.listw(w_matrix, Bias_map$bias, NAOK=TRUE)
    # Save spatial lag in additional column
    Bias_map$bias_w <- bias_w

    cat("The number of disconnected subgraphs for fbw is: ", subgraphs, "\n")

    Bias_map_fbw  <- Bias_map
    subgraphs_fbw <- subgraphs
    w_matrix_fbw  <- w_matrix
  }
  print("================================================================ 6.3.Option 3: Neighbourhoods based on k-nearest neighbours")
  {
    print("================================================================ 6.3.1.Searching for the optimum k and the lowest number of subgraphs")
    if ("bias_w" %in% colnames(Bias_map)) {
      Bias_map <- Bias_map[, !names(Bias_map) %in% "bias_w"]
    }
    suffix <- '_w_knn'

    # === Extract the coordinates of the centroids (or your points)
    coords <- st_coordinates(st_centroid(Bias_map))

    # === Range of k values to explore
    k_values <- 1:20

    # === List for storing results
    moran_results_list <- list()

    # === Variables for storing the best k and its weight matrix
    best_k_combined <- NA
    best_w_matrix_combined <- NULL
    max_moran_abs_connected <- -Inf
    min_components <- Inf

    # === Loop to iterate over the values of k
    for (k in k_values)
    {
      # Create k-Nearest Neighbors list with k = k
      nb_knn <- knearneigh(coords, k = k)

      # Convertir la lista de k-vecinos a lista de vecindad
      w_knn <- knn2nb(nb_knn)

      # Compute distances from observation to neighbours
      k.distances <- nbdists(w_knn, coords)

      # Calculate weights as the inverse of the distance
      invd_list <- lapply(k.distances, function(x) if (length(x) > 0) (1/(x/100)) else numeric(0))

      # Create the normalised spatial weights matrix
      w_matrix <- nb2listw(w_knn, glist = invd_list, style = "W")

      # Calculate Moran's Index I (analytical test)
      moran_test <- moran.test(Bias_map$bias, w_matrix)
      current_moran_abs <- abs(moran_test$estimate[["Moran I statistic"]])

      # Calculate the number of disconnected subgraphs
      num_components <- n.comp.nb(w_knn)$nc

      # Store the results in the list
      moran_results_list[[as.character(k)]] <- data.frame(
        k = k,
        Moran.I = moran_test$estimate[["Moran I statistic"]],
        p.value = moran_test$p.value,
        Subgraphs = num_components
      )

      # Updating the best k based on the combined criteria
      if (num_components < min_components) {
        min_components <- num_components
        max_moran_abs_connected <- current_moran_abs
        best_k_combined <- k
        best_w_matrix_combined <- w_matrix
      } else if (num_components == min_components && current_moran_abs > max_moran_abs_connected) {
        max_moran_abs_connected <- current_moran_abs
        best_k_combined <- k
        best_w_matrix_combined <- w_matrix
      }

      # Print the results for each k
      cat(paste("k =", k, ", Moran's I =", round(moran_test$estimate[["Moran I statistic"]], 4), ", p-value =", round(moran_test$p.value, 4), ", Subgraphs =", num_components, "\n"))
    }

    # Create the results dataframe
    moran_results_df <- do.call(rbind, moran_results_list)

    # Show he results dataframe
    moran_results_df$p.value <- sprintf("%.10f", moran_results_df$p.value)
    print("\nResults of the iterations:")
    print(moran_results_df)

    # Print the optimal value of k (combined criteria)
    cat(paste("\nThe optimal k-value (based on lower number of subgraphs and higher absolute value of Moran's I-index) is:", best_k_combined, "\n"))

    # --- Calculate and display Moran's I-index and the p-value for the combined optimal k ---
    if (!is.null(best_w_matrix_combined)) {
      best_moran_test_combined <- moran.test(Bias_map$bias, best_w_matrix_combined)
      cat(paste("Índice I de Moran para k =", best_k_combined, ":", round(best_moran_test_combined$estimate[["Moran I statistic"]], 4), "\n"))
      cat(paste("p-value para k =", best_k_combined, ":", round(best_moran_test_combined$p.value, 4), "\n"))

      # Monte Carlo test for the combined optimum k
      mc_best_k_combined <- moran.mc(Bias_map$bias, best_w_matrix_combined, nsim = 999, alternative = "two.sided")
      print(paste("\nMonte Carlo test for k =", best_k_combined, ":"))
      print(mc_best_k_combined)
      print(paste("P-value (Monte Carlo) for k =", best_k_combined, ":", mc_best_k_combined$p.value))

      # Calculate the spatial lag using the optimal weighting matrix (combined criteria)
      bias_lag_optimal_k_combined <- lag.listw(best_w_matrix_combined, Bias_map$bias, NAOK=TRUE)
      print("\nSpatial Lag of bias using the optimal weighting matrix (combined criteria):")
      print(head(bias_lag_optimal_k_combined)) # Display the first rows of the spatial lag
    } else {
      cat("No valid values for k.\n")
    }

    # --- Display of the results ---
    # Function to apply common themes and improve readability
    my_theme <- function() {
      theme_bw() +
        theme(
          plot.title = element_text(size = 28, face = "bold"),
          axis.title = element_text(size = 26),
          axis.text = element_text(size = 24)
          # legend.title = element_text(size = 14),
          # legend.text = element_text(size = 12)
        )
    }
    results_df <- do.call(rbind, lapply(moran_results_list, as.data.frame))

    img_morans <- ggplot(results_df, aes(x = k, y = Moran.I)) +
      geom_line() +
      geom_point() +
      geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
      labs(title = "Moran's I-index for different values of k",
           x = "Number of neighbours (k)",
           y = "Moran Index I") +
      my_theme()

    img_pvalue <- ggplot(results_df, aes(x = k, y = p.value)) +
      geom_line() +
      geom_point() +
      geom_hline(yintercept = 0.05, linetype = "dashed", color = "blue") +
      labs(title = "P-value of the Moran I-index for different values of k",
           x = "Number of neighbours (k)",
           y = "P-value") +
      my_theme()

    img_subgraphs <- ggplot(results_df, aes(x = k, y = Subgraphs)) +
      geom_line() +
      geom_point() +
      scale_y_continuous(breaks = function(x) floor(min(x)):ceiling(max(x))) +
      labs(title = "Number of Disconnected Subgraphs per value of k",
           x = "Number of neighbours (k)",
           y = "Number of Subgraphs") +
      my_theme() +
      ylim(floor(min(results_df$Subgraphs)) - 0.5, ceiling(max(results_df$Subgraphs)) + 0.5)

    # --- La matriz de pesos óptima (combinada) está en 'best_w_matrix_combined'
    # --- y el spatial lag en 'bias_lag_optimal_k_combined' ---
    # --- El dataframe de resultados está en 'moran_results_df' ---
    best_k_combined
    knn_figure <- img_morans + img_pvalue + img_subgraphs
  }
  print("================================================================ 6.3.2.Saving knn analysis")
  {
    # Try to write the CSV file and save the result.
    write_output <- try(write.csv(moran_results_df, file.path(Outputs,paste0("Knn_Analysis_",best_k_combined, ".csv")), fileEncoding = "latin1", row.names = FALSE))
    # Check if there were any errors during writing
    if (inherits(write_output, "try-error")) {
      cat(paste0("Error saving: 'Knn_Analysis_",best_k_combined, ".csv' in '", Outputs, "'.\n"))
      cat("Error message: ", as.character(write_output), "\n")
    } else {
      cat(paste0("Knn_Analysis_",best_k_combined, ".csv successfully created in '", Outputs, "'.\n"))
    }

    write_output <- try(ggsave(paste0(Outputs,"/Knn_plots.png"), knn_figure, width = 18, height = 6, units = "in"))
    # Check if there were any errors during saving
    if (inherits(write_output, "try-error")) {
      cat(paste0("Error saving: 'Knn_plots.png' in '", Outputs,".\n"))
      cat("Error message: ", as.character(write_output), "\n")
    } else {
      cat(paste0("Knn_plots.png successfully created in '", Outputs,".\n"))
    }
  }
  print("================================================================ 6.3.3.Generating the matrix of weights")
  {
    if ("bias_w" %in% colnames(Bias_map)) {
      Bias_map <- Bias_map[, !names(Bias_map) %in% "bias_w"]
    }
    suffix <- '_w_knn'
    # Extract the coordinates of the centroids (or your points)
    coords <- st_coordinates(st_centroid(Bias_map))
    # Create k-Nearest Neighbors list with k = 10 (using centroids of a spatial object)
    nb_knn <- knearneigh(coords, k = best_k_combined)
    # Create weights matrix with equal weights
    w_knn <- knn2nb(nb_knn)
    # Subgraphs
    subgraphs <- n.comp.nb(w_knn)$nc
    # Compute distances from observation to neighbours
    k.distances <- nbdists(w_knn, coords)
    # Use these distances as weights
    invd2a <- lapply(k.distances, function(x) (1/(x/100)))
    # Create weights matrix with weights as 1/d, normalised
    w_matrix <- nb2listw(w_knn, glist = invd2a, style = "W")
    # Compute spatial lag
    bias_w <- lag.listw(w_matrix, Bias_map$bias, NAOK=TRUE)
    # Save spatial lag in additional column
    Bias_map$Bias_w <- bias_w

    cat("The number of disconnected subgraphs for the optimal k (", best_k_combined, ") is: ", subgraphs, "\n")

    Bias_map_knn  <- Bias_map
    subgraphs_knn <- subgraphs
    w_matrix_knn  <- w_matrix
  }
  print("================================================================ 6.4.Option 4: Neighbourhoods based on distance band")
  {
    if ("bias_w" %in% colnames(Bias_map)) {
      Bias_map <- Bias_map[, !names(Bias_map) %in% "bias_w"]
    }
    suffix <- '_w_db'
    # Extract the coordinates of the centroids (or your points)
    coords <- st_coordinates(st_centroid(Bias_map))
    # Compute distance band to ensure that all the observations have neighbours
    k1 <- knn2nb(knearneigh(coords))
    critical.threshold <- max(unlist(nbdists(k1, coords)))
    # Compute lists of neighbours
    nb.dist.band <- dnearneigh(coords, 0, critical.threshold)
    # Subgraphs
    subgraphs <- n.comp.nb(nb.dist.band)$nc
    # Compute distances
    distances <- nbdists(nb.dist.band, coords)
    # Compute inverse distances
    invd1a <- lapply(distances, function(x) (1/(x/100)))
    # Compute spatial weights matrix, normalised
    w_matrix <- nb2listw(nb.dist.band, glist = invd1a, style = "W", zero.policy=TRUE)
    # Compute spatial lag
    bias_w <- lag.listw(w_matrix, Bias_map$bias, NAOK=TRUE)
    # Save spatial lag in additional column
    Bias_map$bias_w <- bias_w

    cat("The number of disconnected subgraphs for db is: ", subgraphs, "\n")

    Bias_map_db  <- Bias_map
    subgraphs_db <- subgraphs
    w_matrix_db  <- w_matrix
  }
  print("================================================================ 6.5.Save data with spatial lag")
  for (w_scheme in w_schemes)
  {
    bias_map_name <- paste0("Bias_map_", w_scheme)
    current_Bias_map <- get(bias_map_name)

    write_output <- try({
      write.csv(st_drop_geometry(current_Bias_map),
                file = file.path(Outputs, paste0("Active_population_bias_", w_scheme, ".csv")),
                fileEncoding = "latin1",
                row.names = FALSE)
    })

    # Check if there were any errors during writing
    if (inherits(write_output, "try-error")) {
      cat(paste0("Error saving: 'Active_population_bias_", w_scheme, ".csv' in '", Outputs, "'.\n"))
      cat("Error message: ", as.character(write_output), "\n")
    } else {
      cat(paste0("Active_population_bias_", w_scheme, ".csv successfully created in '", Outputs, "'.\n"))
    }
  }
  print("================================================================ 6.6.Moran's I, p_value & Z-score (only for spatial cases)")
  # Final dataframe
  all_moran_results <- data.frame(
    Scheme = character(),
    Moran_I_mc = numeric(),
    P_value_mc = numeric(),
    Subgraphs = integer(),
    Moran_I_test = numeric(),
    Expected_Moran_I = numeric(),
    Variance_Moran_I = numeric(),
    P_value_test = numeric(),
    Z_score = numeric(),
    stringsAsFactors = FALSE
  )

  for (w_scheme in w_schemes) {
    # Build variable names dynamically
    bias_map_name <- paste0("Bias_map_", w_scheme)
    w_matrix_name <- paste0("w_matrix_", w_scheme)
    subgraphs_name <- paste0("subgraphs_", w_scheme)

    # Use get() to get the actual objects by their names
    current_Bias_map <- get(bias_map_name)
    current_w_matrix <- get(w_matrix_name)
    current_subgraphs <- get(subgraphs_name)

    cat(paste0("\n--- Processing scheme: ", w_scheme, " ---\n"))

    # Moran's I Monte Carlo test
    result <- moran.mc(current_Bias_map$bias, current_w_matrix, nsim = 1000, alternative = "two.sided", zero.policy = TRUE)

    # Extract Moran's I and p-value
    mI <- as.numeric(result$statistic)
    p_value_mI <- as.numeric(result$p.value)
    print(paste("P_value (moran.mc) =", p_value_mI))
    print(paste("mI (moran.mc)      =", mI))

    # Execute moran.test()
    moran_test_result <- moran.test(current_Bias_map$bias, current_w_matrix, alternative = "two.sided", zero.policy = TRUE)

    # Extracts the Z-score
    z_score_mI <- as.numeric(moran_test_result$statistic)
    expected_mI <- as.numeric(moran_test_result$estimate["Expectation"])
    variance_mI <- as.numeric(moran_test_result$estimate["Variance"])

    # Extracts Moran's I observed and p-value
    observed_mI_test <- as.numeric(moran_test_result$estimate["Moran I statistic"])
    p_value_test <- as.numeric(moran_test_result$p.value)

    # Collect the results in one row for the final data.frame
    # Create a row with the results for the current scheme
    current_row <- data.frame(
      Scheme = w_scheme,
      Moran_I_mc = mI,
      P_value_mc = p_value_mI,
      Subgraphs = as.integer(current_subgraphs),
      Moran_I_test = observed_mI_test,
      Expected_Moran_I = expected_mI,
      Variance_Moran_I = variance_mI,
      P_value_test = p_value_test,
      Z_score = z_score_mI,
      stringsAsFactors = FALSE
    )

    # Add this row to the main data.frame
    all_moran_results <- rbind(all_moran_results, current_row)

    # code to save individual CSVs
    Moran_Pvalue_individual <- data.frame(
      Statistic = c(
        "Moran's I (moran.mc)",
        "P_value (moran.mc)",
        "Subgraphs",
        "Moran's I (moran.test)",
        "Expected Moran's I",
        "Variance of Moran's I",
        "P_value (moran.test)",
        "Z-score"
      ),
      Value = c(
        mI,
        p_value_mI,
        as.integer(current_subgraphs),
        observed_mI_test,
        expected_mI,
        variance_mI,
        p_value_test,
        z_score_mI
      )
    )
    Moran_Pvalue_individual$Value <- format(Moran_Pvalue_individual$Value, scientific = FALSE, digits = 10)
    print("DataFrame Moran_Pvalue_individual formatted (to text):")
    print(Moran_Pvalue_individual)

    if(FALSE)
    {
      write_output <- try({
        write.csv(
          Moran_Pvalue_individual,
          file = file.path(Outputs, paste0("Moran_Pvalue_", w_scheme, ".csv")),
          fileEncoding = "latin1",
          row.names = FALSE
        )
      })

      if (inherits(write_output, "try-error")) {
        cat(paste0("Error saving: 'Moran_Pvalue_", w_scheme, ".csv' in '", Outputs, "'.\n"))
        cat("Error message: ", as.character(write_output), "\n")
      } else {
        cat(paste0("Moran_Pvalue_", w_scheme, ".csv successfully created in '", Outputs, "'.\n"))
      }
    }
  }

  # Format and save the consolidated data.frame
  # Format the numeric columns of the consolidated data.frame to avoid scientific notation.
  # Exclude ‘Scheme’ and ‘Subgraphs’ as they do not need it.
  cols_to_format <- c("Moran_I_mc",
                      "P_value_mc",
                      "Moran_I_test",
                      "Expected_Moran_I",
                      "Variance_Moran_I",
                      "P_value_test",
                      "Z_score")

  for (col_name in cols_to_format) {
    if (col_name %in% names(all_moran_results)) {
      all_moran_results[[col_name]] <- format(all_moran_results[[col_name]], scientific = FALSE, digits = 10)
    }
  }

  cat("\n--- Data.frame of all Moran's I results")
  print(all_moran_results)

  # Saving final data.frame
  write_output_final <- try({
    write.csv(
      all_moran_results,
      file = file.path(Outputs, "All_Moran_Pvalues.csv"),
      fileEncoding = "latin1",
      row.names = FALSE
    )
  })

  if (inherits(write_output_final, "try-error")) {
    cat(paste0("Error saving consolidated file: 'All_Moran_Pvalues.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output_final), "\n")
  } else {
    cat(paste0("All_Moran_Pvalues.csv successfully created in '", Outputs, "'.\n"))
  }
  print("================================================================ 7.Map bias")
  {
    # Bias_map is defined in 6.Spatial autocorrelation section
    # Bias_map

    # Dividing data into intervals
    jenks_breaks <- classIntervals(Bias_measurement$bias*100, n = num_classes, style = "jenks")$brks

    # Assigns unique intervals
    jenks_breaks <- unique(jenks_breaks)
    print("Breaks:")
    print(jenks_breaks)

    # Create a new factor based on Jenks breaks
    Bias_map$jenks_bins <- cut(Bias_map$Map_bias, jenks_breaks, include.lowest = TRUE)

    # Bias_map

    # Create a custom color palette from viridis
    jenks_colors <- viridis(length(jenks_breaks) - 1)

    # Manually format the legend labels to avoid scientific notation
    formatted_labels <- sapply(1:(length(jenks_breaks) - 1), function(i) {
      paste0("[",
             sprintf("%.1f", jenks_breaks[i]), ", ",
             sprintf("%.1f", jenks_breaks[i + 1]), ")")
    })
    print("Labels:")
    print(formatted_labels)
    # Nonspatial
    {
      Map_nonspatial <- ggplot(data = Bias_map) +
        geom_sf(aes(fill = jenks_bins)) +
        scale_fill_viridis_d(name = "Size of bias",
                             labels = formatted_labels,
                             na.translate = TRUE,
                             na.value = "gray") +  # Set color for NA values
        labs(title = " ") +
        theme_map_tufte() +
        theme(
          legend.text = element_text(size = 60),
          legend.title = element_text(size = 60),
          legend.position = "right"
        )
    }

    # Saving
    w_scheme <- "nonspatial"
    write_output <- try(ggsave(file.path(Outputs, paste0("/Map/Map_", w_scheme,".png")), plot = Map_nonspatial, bg = "white"))
    # Check if there were any errors during saving
    if (inherits(write_output, "try-error")) {
      cat(paste0("Error saving: 'Map_", w_scheme,".png' in '", Outputs, "/Map'.\n"))
      cat("Error message: ", as.character(write_output), "\n")
    } else {
      cat(paste0("Map_", w_scheme,".png successfully created in '", Outputs, "/Map'.\n"))
    }

    # BUCLE

    for (w_scheme in w_schemes) {
      # Gets the current Bias_map (‘sf’ object)
      bias_map_name <- paste0("Bias_map_", w_scheme)
      current_Bias_map <- get(bias_map_name)

      # --- GET mI and p_value_mI FROM all_moran_results ---
      # Filter ‘all_moran_results’ for the row corresponding to the current scheme
      current_moran_stats <- all_moran_results[all_moran_results$Scheme == w_scheme, ]

      # Checks if data was found for the current scheme
      if (nrow(current_moran_stats) == 0) {
        cat(paste0("Warning: No Moran statistics were found for the scheme ", w_scheme, ". Map generation is omitted.\n"))
        next # Goes to the next iteration of the loop
      }

      # Extracts the values of mI and p_value_mI from the filtered row
      mI <- as.numeric(current_moran_stats$Moran_I_mc)
      p_value_mI <- as.numeric(current_moran_stats$P_value_mc) # Using P_value from moran.mc

      cat(paste0("\n--- Generating map for the scheme:: ", w_scheme, " ---\n"))

      # Assign ‘jenks_bins’ to current_Bias_map
      current_Bias_map$jenks_bins <- cut(current_Bias_map$Map_bias, jenks_breaks, include.lowest = TRUE)

      # Prepare the annotation for the map
      p_annotation <- ifelse(p_value_mI < 0.05, "p < 0.05", paste("p =", round(p_value_mI, 2)))
      bbox <- st_bbox(Bias_map)
      xmin <- bbox["xmin"]
      xmax <- bbox["xmax"]
      ymin <- bbox["ymin"]
      ymax <- bbox["ymax"]
      annotation <- data.frame(
        x = c(xmin + 0.5*(xmax-xmin), xmin + 0.5*(xmax-xmin)),
        y = c(ymin + 1.25*(ymax-ymin), ymin + 1.15*(ymax-ymin)),
        label = c(paste0("I = ", round(mI,2)), p_annotation)
      )

      # Build the map graphic
      Map <- ggplot(data = current_Bias_map) +
        geom_sf(aes(fill = jenks_bins)) +
        scale_fill_viridis_d(name = "Size of bias",
                             labels = formatted_labels,
                             na.translate = FALSE,
                             na.value = "gray") +  # Set color for NA values
        labs(title = " ") +
        geom_text(data=annotation, aes(x=x, y=y, label=label),
                  color="black",
                  size=23,
                  angle=0,
                  fontface="bold",
                  family = "robotocondensed") +
        theme_map_tufte() +
        theme(
          legend.text = element_text(size = 55),
          legend.title = element_text(size = 55),
          legend.position = "right",
          axis.title = element_blank(),        # Remove axis titles
          axis.text = element_blank(),         # Remove axis text
          axis.ticks = element_blank()         # Remove axis ticks
        )

      # Map
      # Saving map
      map_filename <- file.path(Outputs, "Map", paste0("Map_", w_scheme, ".png"))
      write_output <- try(ggsave(map_filename, plot = Map, bg = "white"))
      # Check if there were any errors during saving
      if (inherits(write_output, "try-error")) {
        cat(paste0("Error saving: 'Map_", w_scheme,".png' in '", Outputs, "/Map'.\n"))
        cat("Error message: ", as.character(write_output), "\n")
      } else {
        cat(paste0("Map_", w_scheme,".png successfully created in '", Outputs, "/Map'.\n"))
      }
    }
  }
  print("================================================================ 8.Final figure")
  {
    # Paths
    map_path <- paste0(Outputs, "/Map/Map_nonspatial.png")
    unlabelled_histogram_path <- paste0(Outputs, "/Histogram/Unlabelled_histogram.png")
    adjusted_histogram_path <- paste0(Outputs, "/Histogram/Adjusted_unlabelled_histogram_50.png")
    scatter_path <- paste0(Outputs,"/Scatter/Scatter.png")

    # LOAD IMAGES
    # ====================================================================== img1 (map)
    if (file.exists(map_path)){
      img1 <- image_read(map_path)
      message("File uploaded: Map_nonspatial.png")
    } else {
      message("Map_nonspatial.png not found.")
    }
    # ============================================================== img2 (histogram)
    if (file.exists(adjusted_histogram_path)) {
      img2 <- image_read(adjusted_histogram_path)
      message("File uploaded: Adjusted_unlabelled_histogram_50.png")
    } else {
      if (file.exists(unlabelled_histogram_path)) {
        img2 <- image_read(unlabelled_histogram_path)
        message("File uploaded: Unlabelled_histogram.png")
      } else {
        stop("Not Adjusted_unlabelled_histogram_50.png nor Unlabelled_histogram.png were found in the path.")
      }
    }

    # =================================================================img3 (scatter)
    if (file.exists(scatter_path)){
      img3 <- image_read(scatter_path)
      message("File uploaded: Scatter.png")
    } else {
      message("Scatter.png not found.")
    }
    # ================================================================= JOIN
    # Join images
    Final_figure <- image_append(c(img1, img2, img3))
  }
  print("================================================================ 8.1.Saving Final figure")
  write_output <- try(image_write(Final_figure, paste0(Outputs,"/Final_figure.png")))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Final_figure.png' in '", Outputs,".\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Final_figure.png successfully created in '", Outputs,".\n"))
  }
  print("=================================================================================")
  print("======================= END OF MEASURE BIAS =====================================")
  print("=================================================================================")
  print(paste("============= Please check the ",Outputs," folder to see results ====================="))
  print("=================================================================================")
  continue <- readline(prompt = "Press ENTER to continue or 0 to return to the main menu: ")
  if (continue == "0")
    next
}
print("============================================================================== THANK YOU FOR USING THE PROGRAM")
print("============================================================================== SEE YOU NEXT TIME")
} # End of the function exe()
