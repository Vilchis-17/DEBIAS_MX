# ==============================================================================
# ======================== F_Load_dependences ==================================
# ==============================================================================
#' F_Load_dependences
#'
#' This function load libraries
#'
#' @param
#'        none
#' @return
#'        none.
#' @examples
#'        F_Load_dependences()
#' @export
F_Load_dependences<-function()
{
  # Clear workspace
  rm(list=ls())

  library(dplyr)
  library(sf)
  library(ggplot2)
  library(viridis)
  library(spdep)
  library(sysfonts)
  library(showtextdb)
  library(classInt)
  library(scales)
  library(forcats)
  library(spgwr)
  library(ggthemes)
  library(showtext)
  library(tmap)
  library(tidyverse)
  library(readr)
  library(magrittr)
  library(gridExtra)
  library(magick)
  library(patchwork)
  print("Libraries loaded . . .")
}
# ==============================================================================
# ======================== F_Measure_bias ======================================
# ==============================================================================
#' F_Measure_bias
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Measure_bias <- function(Population_data,Active_population)
{
  # Join dataframes
  Bias_measurement <- Population_data %>% left_join(Active_population, by = "Area_code")
  # Create Bias column
  Bias_measurement$bias <- 1 - (Bias_measurement$Total_active_population)/(Bias_measurement$Total_Population)
  # Create Map_bias column
  Bias_measurement$Map_bias <- (Bias_measurement$bias * 100)
  # Select columns
  Bias_measurement<- Bias_measurement %>%
    select(Area_code,
           Area_name.x,
           Total_Population,
           Total_active_population,
           bias,
           Map_bias)%>%
    rename("Area_name" = "Area_name.x")
  return(Bias_measurement)
}
# ==============================================================================

# ==============================================================================
# ======================== F_Correlation_graph =================================
# ==============================================================================
#' F_Correlation_graph
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Correlation_graph <- function(Bias_measurement)
{
  # Create the correlation graph
  return(ggplot(Bias_measurement, aes(x = Total_Population, y = Total_active_population)) +
    geom_point() +
    labs(title = "CORRELATION GRAPH",
         x = "Total Population",
         y = "Total Active Population") +
    theme_bw() +
    #theme_plot_tufte() +
    theme(axis.text.x = element_text(size = 40),
          axis.text.y = element_text(size = 40),
          axis.title.x = element_text(size = 40),
          axis.title.y = element_text(size = 40),
          plot.title = element_text(size = 40)))
}
# ==============================================================================

# ==============================================================================
# ======================== F_Create_outputs_folder =============================
# ==============================================================================
#' F_Create_outputs_folder
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Create_outputs_folder <- function(Outputs)
{
  # 1. Create the main folder if it does not exist
  if (!dir.exists(Outputs)) {
    dir.create(Outputs)
    cat(paste0("Main Folder Output '", Outputs, "' successfully created.\n"))
  } else {
    cat(paste0("Main Folder Output '", Outputs, "' already exists.\n"))
  }

  # 2. Create the subfolders inside the main folder.
  Subfolders <- c("Scatter", "Histogram", "Map")
  for (Subfolder in Subfolders) {
    path_subfolder <- file.path(Outputs, Subfolder)
    if (!dir.exists(path_subfolder)) {
      dir.create(path_subfolder)
      cat(paste0("Subfolder '", Subfolder, "' created in '", Outputs, "' successfully.\n"))
    } else {
      cat(paste0("Subfolder '", Subfolder, "' already exists in '", Outputs, "'.\n"))
    }
  }
  cat("Folder creation process completed.\n")
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_data_information =============================
# ==============================================================================
#' F_Saving_data_information
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_data_information <- function(Outputs,data_information)
{
  # Try to write the CSV file and save the result.
  write_output <- try(write.csv(data_information, file.path(Outputs, "Data_information.csv"), fileEncoding = "latin1", row.names = FALSE))
  # Check if there were any errors during writing
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Data_information.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Data_information.csv successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_correlation_graph ==========================
# ==============================================================================
#' F_Saving_correlation_graph
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_correlation_graph <- function(Outputs,correlation_graph)
{
  # Saving correlation graph
  write_output <- try(ggsave(file.path(Outputs, "/Correlation_graph.png"), plot = correlation_graph, bg = "white"))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Correlation_graph.png' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Correlation_graph.png successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_measure_bias ===============================
# ==============================================================================
#' F_Saving_measure_bias
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_measure_bias <- function(Outputs,Bias_measurement)
{
  # NON-SPATIAL
  # Try to write the CSV file and save the result.
  write_output <- try(write.csv(Bias_measurement, file.path(Outputs, "Active_population_bias_nonspatial.csv"), fileEncoding = "latin1", row.names = FALSE))
  # Check if there were any errors during writing
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Active_population_bias_nonspatial.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Active_population_bias_nonspatial.csv successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_missing_values =============================
# ==============================================================================
#' F_Saving_missing_values
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_missing_values <- function(Outputs,Bias_measurement_NA)
{
  # Try to write the CSV file and save the result.
  write_output <- try(write.csv(Bias_measurement_NA, file.path(Outputs, "Active_population_bias_NA.csv"), fileEncoding = "latin1", row.names = FALSE))
  # Check if there were any errors during writing
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Active_population_bias_NA.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Active_population_bias_NA.csv successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_negative_bias ==============================
# ==============================================================================
#' F_Saving_negative_bias
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_negative_bias <- function(Outputs,Bias_measurement_NEG)
{
  # Try to write the CSV file and save the result.
  write_output <- try(write.csv(Bias_measurement_NEG, file.path(Outputs, "Active_population_bias_NEG.csv"), fileEncoding = "latin1", row.names = FALSE))
  # Check if there were any errors during writing
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Active_population_bias_NEG.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Active_population_bias_NEG.csv successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_original_data ==============================
# ==============================================================================
#' F_Saving_original_data
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_original_data <- function(Outputs,Bias_measurement_ORI)
{
  # Try to write the CSV file and save the result.
  write_output <- try(write.csv(Bias_measurement_ORI, file.path(Outputs, "Active_population_bias_ORI.csv"), fileEncoding = "latin1", row.names = FALSE))
  # Check if there were any errors during writing
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Active_population_bias_ORI.csv' in '", Outputs, "'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Active_population_bias_ORI.csv successfully created in '", Outputs, "'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ============================== F_Scatter_plot ================================
# ==============================================================================
#' F_Scatter_plot
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Scatter_plot <- function(Bias_measurement,num_classes)
{
  # Dividing data into intervals
  jenks_breaks <- classIntervals(Bias_measurement$bias*100, n = num_classes, style = "jenks")$brks

  # Assigns unique intervals
  jenks_breaks <- unique(jenks_breaks)
  print("Breaks:")
  print(jenks_breaks)

  # Create a factor variable for color breaks
  Bias_measurement$jenks_bins <- cut(Bias_measurement$bias*100, breaks = jenks_breaks, include.lowest = TRUE)

  # Create a custom color palette from viridis
  jenks_colors <- viridis(length(jenks_breaks) - 1)

  # Manually format the legend labels to avoid scientific notation
  formatted_labels <- sapply(1:(length(jenks_breaks) - 1), function(i) {
    paste0("[",
           sprintf("%.1f", jenks_breaks[i]), ", ",
           sprintf("%.1f", jenks_breaks[i + 1]), ")")
  })
  print("Labels:")
  print(formatted_labels)

  # Perform the Pearson correlation test, removing NA values
  correlation_test <- cor.test(Bias_measurement$Total_Population, Bias_measurement$Total_active_population, use = "complete.obs", method = "pearson")
  correlation_coefficient <- round(correlation_test$estimate, 2)
  p_value <- correlation_test$p.value
  p_annotation <- ifelse(p_value < 0.05, "p < 0.05", paste("p =", round(p_value, 2)))
  annotation <- data.frame(
    x = c(max(Bias_measurement$Total_Population * 0.6, na.rm = TRUE),
          max(Bias_measurement$Total_Population * 0.6, na.rm = TRUE)),
    y = c(max(Bias_measurement$Total_active_population * 0.95, na.rm = TRUE),
          max(Bias_measurement$Total_active_population * 0.85, na.rm = TRUE)),
    label = c(paste0("r = ", correlation_coefficient), p_annotation)
  )

  annotation

  # Create the plot
  Scatter_plot <- ggplot(Bias_measurement, aes(x = Total_Population, y = Total_active_population, color = jenks_bins)) +
    geom_point(size = 5, alpha = 0.6, stroke = 0.7) +
    scale_color_viridis_d(
      na.translate = TRUE,
      na.value = "gray"  # Color for NA values
    ) +
    labs(
      x = "Total population",
      y = "Total active population"
    ) +
    geom_text(data=annotation, aes(x=x, y=y, label=label),
              color="black",
              size=25,
              angle=0,
              fontface="bold",
              family = "robotocondensed") +
    scale_x_continuous(labels = label_number(scale = 0.001, suffix = " k")) +
    scale_y_continuous(labels = label_number(scale = 0.001, suffix = " k")) +
    theme_plot_tufte() +
    theme(axis.title.x = element_text(size = 60),  # Set font size for X-axis title
          axis.title.y = element_text(size = 60),   # Set font size for Y-axis title
          axis.text.x = element_text(size = 50),     # Font size for X-axis ticks
          axis.text.y = element_text(size = 50),
          legend.position = "none",
          plot.margin = unit(c(1, 2, 1, 1), "lines")
    )
  return(Scatter_plot)
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_scatter_plot ===============================
# ==============================================================================
#' F_Saving_original_data
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_scatter_plot <- function(Outputs,Scatter_plot)
{
  write_output <- try(ggsave(file.path(Outputs, "/Scatter/Scatter.png"), plot = Scatter_plot, bg = "white"))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Scatter.png' in '", Outputs, "/Scatter'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Scatter.png successfully created in '", Outputs, "/Scatter'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ==================== F_Labelled_Unlabelled_Histograms ========================
# ==============================================================================
#' F_Labelled_Unlabelled_Histograms
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Labelled_Unlabelled_Histograms  <- function(Bias_measurement,num_classes,option)
{
  # Dividing data into intervals
  jenks_breaks <- classIntervals(Bias_measurement$bias*100, n = num_classes, style = "jenks")$brks

  # Assigns unique intervals
  jenks_breaks <- unique(jenks_breaks)

  # Create a data frame with histogram information
  hist_data <- data.frame(value = Bias_measurement$bias*100)

  # Create a factor variable for color breaks
  hist_data$jenks_bins <- cut(hist_data$value, breaks = jenks_breaks, include.lowest = TRUE)

  # Create a custom color palette from viridis
  jenks_colors <- viridis(length(jenks_breaks) - 1)

  # Manually format the legend labels to avoid scientific notation
  formatted_labels <- sapply(1:(length(jenks_breaks) - 1), function(i) {
    paste0("[",
           sprintf("%.1f", jenks_breaks[i]), ", ",
           sprintf("%.1f", jenks_breaks[i + 1]), ")")
  })

  minimum_x <- sort(hist_data$value)[1]
  binwidth <- .16

  if(option == 1)
  {
    # Plot the labelled histogram with ggplot
    Labelled_histogram <- ggplot(hist_data, aes(x = value, fill = jenks_bins)) +
      xlim(minimum_x, 100) +
      geom_histogram(binwidth=binwidth, color = "black", linewidth = 0.3) +  # Adjust binwidth as needed
      scale_fill_viridis_d(
        name = "Size of bias",
        labels = formatted_labels,
        na.translate = TRUE,
        na.value = "gray"  # Set color for NA values
      ) +
      labs(x = "Size of bias", y = "Frequency") +
      theme_plot_tufte() +
      theme(
        legend.text = element_text(size = 60),    # Increase legend text size
        legend.title = element_text(size = 60),   # Increase legend title size
        legend.position = "right",                # Optional: adjust legend position
        axis.title.x = element_text(size = 63),   # Set font size for X-axis title
        axis.title.y = element_text(size = 63),   # Set font size for Y-axis title
        axis.text.x = element_text(size = 50),    # Font size for X-axis ticks
        axis.text.y = element_text(size = 50)     # Font size for Y-axis ticks
      )
    return(Labelled_histogram)
  }
  if(option == 0)
  {
    # Plot the unlabelled histogram with ggplot
    Unlabelled_histogram <- ggplot(hist_data, aes(x = value, fill = jenks_bins)) +
      xlim(minimum_x ,100) +
      geom_histogram(binwidth=binwidth, color = "black", linewidth = 0.3) +
      scale_fill_viridis_d(
        name = "Size of bias",
        labels = formatted_labels,
        na.translate = TRUE,
        na.value = "gray",
        guide = "none"
      ) +
      labs(x = "Size of bias", y = "Frequency") +
      theme_plot_tufte() +
      theme(
        axis.title.x = element_text(size = 63),
        axis.title.y = element_text(size = 63),
        axis.text.x = element_text(size = 50),
        axis.text.y = element_text(size = 50),
        legend.position = "none"
      )
    return(Unlabelled_histogram)
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_labelled_histogram =========================
# ==============================================================================
#' F_Saving_labelled_histogram
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_labelled_histogram <- function(Outputs,Labelled_histogram)
{
  write_output <- try(ggsave(file.path(Outputs, "/Histogram/Labelled_histogram.png"), plot = Labelled_histogram, bg = "white"))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Labelled_histogram.png' in '", Outputs, "/Histogram'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Labelled_histogram.png successfully created in '", Outputs, "/Histogram'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ======================== F_Saving_unlabelled_histogram =========================
# ==============================================================================
#' F_Saving_unlabelled_histogram
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_unlabelled_histogram <- function(Outputs,Unlabelled_histogram)
{
  write_output <- try(ggsave(file.path(Outputs, "/Histogram/Unlabelled_histogram.png"), plot = Unlabelled_histogram, bg = "white"))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Unlabelled_histogram.png' in '", Outputs, "/Histogram'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Unlabelled_histogram.png successfully created in '", Outputs, "/Histogram'.\n"))
  }
}
# ==============================================================================

# ==============================================================================
# ==================== F_Adjusted_unlabelled_histogram =========================
# ==============================================================================
#' F_Adjusted_unlabelled_histogram
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Adjusted_unlabelled_histogram  <- function(Bias_measurement,num_classes)
{
  # min_x_values <- c(50, 60, 70, 80, 90)
  min_x <- 50

  # Dividing data into intervals
  jenks_breaks <- classIntervals(Bias_measurement$bias*100, n = num_classes, style = "jenks")$brks

  # Assigns unique intervals
  jenks_breaks <- unique(jenks_breaks)

  # Create a data frame with histogram information
  hist_data <- data.frame(value = Bias_measurement$bias*100)

  # Create a factor variable for color breaks
  hist_data$jenks_bins <- cut(hist_data$value, breaks = jenks_breaks, include.lowest = TRUE)

  # Crear la paleta de colores viridis con el número de breaks - 1
  jenks_colors <- viridis(length(jenks_breaks) - 1)

  # Obtener los niveles únicos de jenks_bins (en el orden en que aparecen)
  unique_bins_ordered <- levels(hist_data$jenks_bins)

  # Asegurarse de que el número de colores coincida con el número de niveles únicos
  if (length(jenks_colors) >= length(unique_bins_ordered)) {
    # Asignar los colores a los niveles únicos
    names(jenks_colors) <- unique_bins_ordered
  } else {
    warning("El número de colores en 'jenks_colors' es menor que el número de intervalos únicos.")
  }

  # Manually format the legend labels
  formatted_labels <- sapply(1:(length(jenks_breaks) - 1), function(i) {
    paste0("[",
           sprintf("%.1f", jenks_breaks[i]), ", ",
           sprintf("%.1f", jenks_breaks[i + 1]), ")")
  })

  binwidth <- .16
    Adjusted_unlabelled_histogram <- ggplot(hist_data, aes(x = value, fill = jenks_bins)) +
      xlim(min_x, 100) + # Establecer el límite inferior dinámicamente
      geom_histogram(binwidth = binwidth, color = "black", linewidth = 0.3) +
      scale_fill_manual(
        name = "Size of bias",
        values = jenks_colors,
        labels = formatted_labels
      ) +
      labs(x = "Size of bias", y = "Frequency") +
      theme_plot_tufte() +
      theme(
        axis.title.x = element_text(size = 63),
        axis.title.y = element_text(size = 63),
        axis.text.x = element_text(size = 50),
        axis.text.y = element_text(size = 50),
        legend.position = "none"
      )
    return(Adjusted_unlabelled_histogram)
}
# ==============================================================================

# ==============================================================================
# ===================== F_Saving_adjusted_unlabelled_histogram =================
# ==============================================================================
#' F_Saving_adjusted_unlabelled_histogram
#'
#'
#'
#' @param
#'
#' @return
#'
#' @examples
#'
#' @export
F_Saving_adjusted_unlabelled_histogram <- function(Outputs,Adjusted_unlabelled_histogram)
{
  min_x = 50
  # Saving Adjusted_unlabelled_histogram_50
  write_output <- try(ggsave(file.path(Outputs, paste0("/Histogram/Adjusted_unlabelled_histogram_", min_x, ".png")), plot = Adjusted_unlabelled_histogram, bg = "white"))
  # Check if there were any errors during saving
  if (inherits(write_output, "try-error")) {
    cat(paste0("Error saving: 'Unlabelled_histogram_", min_x, ".png' in '", Outputs, "/Histogram'.\n"))
    cat("Error message: ", as.character(write_output), "\n")
  } else {
    cat(paste0("Adjusted_unlabelled_histogram_", min_x, ".png successfully created in '", Outputs, "/Histogram'.\n"))
  }
}
# ==============================================================================
# ==============================================================================
# ======================== theme_map_tufte =====================================
# ==============================================================================
#' theme_map_tufte
#'
#' This function applies a custom theme to the maps.
#'
#' @param
#'        none
#' @return
#'        A ggplot2 theme object.
#' @examples
#'        theme_map_tufte()
#' @export
theme_map_tufte <- function(...)
{
  theme_tufte() +
    theme(
      text = element_text(family = "robotocondensed"),
      # remove all axes
      axis.text.x = element_blank(),
      axis.text.y = element_blank(),
      axis.ticks = element_blank()
    )
}
# ==============================================================================
# ======================== theme_plot_tufte =====================================
# ==============================================================================
#' theme_plot_tufte
#'
#' This function applies a custom theme to the plots.
#'
#' @param
#'        none
#' @return
#'        A ggplot2 theme object.
#' @examples
#'        theme_plot_tufte()
#' @export
theme_plot_tufte <- function(...)
{
  theme_tufte() +
    theme(
      text = element_text(family = "robotocondensed")
    ) +
    theme(axis.text.y = element_text(size = 12),
          axis.text.x = element_text(size = 12),
          axis.title=element_text(size=14)
    )
}
